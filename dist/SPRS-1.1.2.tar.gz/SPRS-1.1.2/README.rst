A Simple Python Request Sender by Minege.

Choosable :

Website

Website Arguments ( Default is '/' )

User-Agent ( Default is Random ) 

Port ( Default is 80 )

return the HTTP Header Reponse in str type
